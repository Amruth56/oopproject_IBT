module.exports = {
  MID: process.env.MID,
  PAYTM_MERCHANT_KEY: process.env.PAYTM_MERCHANT_KEY,
  PAYTM_FINAL_URL: process.env.PAYTM_FINAL_URL,
  WEBSITE: process.env.WEBSITE,
  CHANNEL_ID: process.env.CHANNEL_ID,
  INDUSTRY_TYPE_ID: process.env.INDUSTRY_TYPE_ID,
  CALLBACK_URL: process.env.CALLBACK_URL
};
